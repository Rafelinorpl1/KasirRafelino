<?php
session_start();
include "koneksi.php";

// Cek apakah ID ada di URL
if (!isset($_GET['ProdukID']) || empty($_GET['ProdukID'])) {
    die("Error: ID produk tidak ditemukan.");
}

$id = intval($_GET['ProdukID']); // Pastikan ID adalah angka

// Hapus produk dari database
$query = "DELETE FROM produk WHERE ProdukID = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo "<script>alert('Produk berhasil dihapus!'); window.location='dashboard.php?page=produk';</script>";
} else {
    echo "<script>alert('Gagal menghapus produk: " . $stmt->error . "');</script>";
}
?>
