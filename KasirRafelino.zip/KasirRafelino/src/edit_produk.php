<?php
session_start();
include "koneksi.php"; 

// Cek apakah ada ID produk yang dikirim
if (!isset($_GET["ProdukID"]) || empty($_GET["ProdukID"]) || !is_numeric($_GET["ProdukID"])) {
    echo "<script>alert('ID Produk tidak ditemukan atau tidak valid!'); window.location='dashboard.php?page=produk';</script>";
    exit();
}

$id = intval($_GET["ProdukID"]); // Pastikan ID adalah angka

// Ambil data produk berdasarkan ID
$query = "SELECT * FROM produk WHERE ProdukID = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$produk = $result->fetch_assoc();


if (isset($_POST["update"])) {
    $nama = trim($_POST["nama"]);
    $harga = intval($_POST["harga"]);
    $stok = intval($_POST["stok"]);

    if (!empty($nama) && $harga > 0 && $stok >= 0) {
        $query = "UPDATE produk SET NamaProduk = ?, Harga = ?, Stok = ? WHERE ProdukID = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("siii", $nama, $harga, $stok, $id);

        if ($stmt->execute()) {
            echo "<script>alert('Produk berhasil diperbarui!'); window.location='dashboard.php?page=produk';</script>";
            exit();
        } else {
            die("Gagal memperbarui produk: " . $stmt->error);
        }
    } else {
        echo "<script>alert('Masukkan data dengan benar!');</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk</title>
    <link href="./output.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex justify-center items-center h-screen">
        <div class="bg-white p-6 rounded-lg shadow-md w-96">
            <h1 class="text-2xl font-bold mb-4 text-center">Edit Produk</h1>
            <form method="POST">
                <label class="block text-sm font-medium">Nama Produk</label>
                <input type="text" name="nama" value="<?= htmlspecialchars($produk['NamaProduk']) ?>" class="border p-2 w-full mb-2" required>

                <label class="block text-sm font-medium">Harga</label>
                <input type="number" name="harga" value="<?= htmlspecialchars($produk['Harga']) ?>" class="border p-2 w-full mb-2" required>

                <label class="block text-sm font-medium">Stok</label>
                <input type="number" name="stok" value="<?= htmlspecialchars($produk['Stok']) ?>" class="border p-2 w-full mb-2" required>

                <button type="submit" name="update" class="bg-blue-500 hover:bg-blue-700 text-white px-4 py-2 rounded w-full mt-2 cursor-pointer">Simpan</button>
            </form>
            <a href="dashboard.php?page=produk" class="block text-center text-gray-600 mt-3">Kembali</a>
        </div>
    </div>
</body>
</html>
