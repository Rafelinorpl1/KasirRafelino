<?php
session_start();
include "koneksi.php"; // Pastikan koneksi ke database sudah benar

// Pastikan ada transaksi_id yang dikirim
if (!isset($_GET['id']) || empty($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "<script>alert('ID transaksi tidak valid!'); window.location='dashboard.php?page=transaksi';</script>";
    exit();
}

$transaksi_id = intval($_GET['id']); // Pastikan transaksi_id dalam bentuk angka

// Mulai transaksi untuk menjaga integritas data
$conn->begin_transaction();

try {
    // Hapus semua detail transaksi terlebih dahulu
    $query_detail = "DELETE FROM transaksi_detail WHERE transaksi_id = ?";
    $stmt_detail = $conn->prepare($query_detail);
    $stmt_detail->bind_param("i", $transaksi_id);
    $stmt_detail->execute();

    // Hapus transaksi utama setelah detailnya dihapus
    $query_transaksi = "DELETE FROM transaksi WHERE id = ?";
    $stmt_transaksi = $conn->prepare($query_transaksi);
    $stmt_transaksi->bind_param("i", $transaksi_id);
    $stmt_transaksi->execute();

    // Commit transaksi jika semua berhasil
    $conn->commit();

    echo "<script>alert('Transaksi berhasil dihapus!'); window.location='dashboard.php?page=transaksi';</script>";
    exit();
} catch (Exception $e) {
    // Rollback jika terjadi error
    $conn->rollback();
    echo "<script>alert('Gagal menghapus transaksi: " . $e->getMessage() . "'); window.location='dashboard.php?page=transaksi';</script>";
    exit();
}

// Tutup koneksi database
$conn->close();
?>
