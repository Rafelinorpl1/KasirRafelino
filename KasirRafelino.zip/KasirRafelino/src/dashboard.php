<?php
session_start();
if (!isset($_SESSION["level"])) {
    header("Location: login.php");
    exit();
}

$role = $_SESSION["level"];
$nama = isset($_SESSION["nama"]) ? $_SESSION["nama"] : "Pengguna";

// Cek apakah baru login agar popup hanya muncul sekali
$showWelcomePopup = false;
if (isset($_SESSION["show_welcome"])) {
    $showWelcomePopup = $_SESSION["show_welcome"];
    unset($_SESSION["show_welcome"]); // Hapus agar tidak muncul lagi setelah refresh
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="./output.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
        </style>
</head>
<body class="bg-gray-300 font-[Poppins]">
<div class="sidebar fixed top-0 bottom-0 lg:left-0 p-2 w-[300px] overflow-y-auto text-center bg-gray-900">
        <div class="text-gray-100">
            <div class="p-2.5 mt-1 flex items-center ">
                <h1 class="font-bold text-gray-200 text-2xl ml-3 cursor-pointer">Kasir Rapel</h1>
            </div>
        </div>
        <hr class="my-2 text-gray-600">

        <a href="?page=dashboard" class="p-2.5 mt-3 flex items-center rounded-md px-4 duration-300 cursor-pointer hover:bg-blue-600 text-white">
            <p class="text-[15px] ml-4 text-gray-200">Home</p>
        </a>

        <a href="?page=produk">
            <div class="p-2.5 mt-3 flex items-center rounded-md px-4 duration-300 cursor-pointer hover:bg-blue-600 text-white">
                <p class="text-[15px] ml-4 text-gray-200">Manajemen Produk</p>
            </div>
        </a>
       
        
        <a href="?page=pelanggan">
            <div class="p-2.5 mt-3 flex items-center rounded-md px-4 duration-300 cursor-pointer hover:bg-blue-600 text-white">
                <p  class="text-[15px] ml-4 text-gray-200">Manajemen Pelanggan</p>
            </div>
        </a>
        
        <?php if ($role == "admin"): ?>
        <a href="?page=petugas">
            <div class="p-2.5 mt-3 flex items-center rounded-md px-4 duration-300 cursor-pointer hover:bg-blue-600 text-white">
                <p  class="text-[15px] ml-4 text-gray-200">Manajemen Petugas</p>
            </div>
        </a>
        <?php endif; ?>
        
        <a href="?page=transaksi">
            <div class="p-2.5 mt-3 flex items-center rounded-md px-4 duration-300 cursor-pointer hover:bg-blue-600 text-white">
                <p class="text-[15px] ml-4 text-gray-200">Transaksi</p>
            </div>
        </a>
        
        <a href="?page=cetak_laporan">
            <div class="p-2.5 mt-3 flex items-center rounded-md px-4 duration-300 cursor-pointer hover:bg-blue-600 text-white">
                <p class="text-[15px] ml-4 text-gray-200">Cetak Laporan</p>
            </div>
        </a>

        <div class="p-2.5 mt-40 flex items-center rounded-md px-4 duration-300 cursor-pointer text-red-500  hover:bg-red-600 hover:text-white">
            <a href="logout.php" class="text-[15px] ml-4 ">Logout</a>
        </div>
    </div>
    
    <!-- POPUP SELAMAT DATANG -->
     <?php if ($showWelcomePopup): ?>
    <div id="welcomePopup" class="fixed inset-0 flex justify-center items-center bg-black bg-opacity-50">
        <div class="bg-white p-6 rounded-lg shadow-lg text-center">
            <?php if ($role == "admin"): ?>
                <h2 class="text-2xl font-bold text-green-600">Selamat Datang, <?= $nama ?>!</h2>
                <p class="text-gray-600 mt-2">Anda masuk sebagai <strong>Admin</strong></p>
                <p class="text-sm text-gray-500">Anda memiliki akses penuh ke sistem</p>
            <?php else: ?>
                <h2 class="text-2xl font-bold text-blue-600">Selamat Datang, <?= $nama ?>!</h2>
                <p class="text-gray-600 mt-2">Anda masuk sebagai <strong>Petugas</strong></p>
                <p class="text-sm text-gray-500">Silakan kelola transaksi dengan baik</p>
            <?php endif; ?>
            <button onclick="closePopup()" class="mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-700">
                OK
            </button>
        </div>
    </div>
    <script>
        function closePopup() {
            document.getElementById("welcomePopup").style.display = "none";
        }
    </script>
    <?php endif; ?>

    <div class="ml-[320px]">
        <?php
        if (isset($_GET['page'])) {
            $page = $_GET['page'];

            // Memasukkan file yang sesuai dengan menu yang diklik
            if ($page == "dashboard") {
                include("dashboard_content.php");
            } elseif ($page == "produk") {
                include("manajemen_produk.php");
            } elseif ($page == "pelanggan") {
                include("manajemen_pelanggan.php");
            } elseif ($page == "petugas") {
                include("manajemen_petugas.php");
            } elseif ($page == "cetak_laporan") {
                include("cetak_laporan.php");
            } elseif ($page == "transaksi") {
                include("transaksi.php");
            } else {
                echo "<div class='p-6 text-white'><h1 class='text-3xl font-bold'>404</h1><p>Halaman tidak ditemukan.</p></div>";
            }
        } else {
            include("dashboard_content.php"); // Default tampil dashboard
        }
        ?>
    </div>
</body>
</html>
