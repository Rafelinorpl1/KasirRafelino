<?php
session_start();
include "koneksi.php";

// Periksa apakah ID petugas dikirim dan valid
if (!isset($_GET["id"]) || empty($_GET["id"]) || !is_numeric($_GET["id"])) {
    echo "<script>alert('ID Petugas tidak valid!'); window.location='dashboard.php?page=petugas';</script>";
    exit();
}

$idPetugas = intval($_GET["id"]);

// Cek apakah petugas ada di database
$query = "SELECT * FROM user WHERE id_user = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $idPetugas);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "<script>alert('Petugas tidak ditemukan!'); window.location='dashboard.php?page=petugas';</script>";
    exit();
}

// Hapus petugas dari database
$query = "DELETE FROM user WHERE id_user = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $idPetugas);

if ($stmt->execute()) {
    echo "<script>alert('Petugas berhasil dihapus!'); window.location='dashboard.php?page=petugas';</script>";
} else {
    echo "<script>alert('Gagal menghapus petugas!');</script>";
}

?>
