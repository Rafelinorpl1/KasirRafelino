<?php
include "koneksi.php";

if (isset($_POST["tambahPelanggan"])) {
    $nama = $_POST["namaPelanggan"];
    $alamat = $_POST["alamat"];
    $no_hp = $_POST["no_hp"];

    $query = "INSERT INTO pelanggan (NamaPelanggan, Alamat, NomorTelepon) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sss", $nama, $alamat, $no_hp);

    if ($stmt->execute()) {
        echo "<script>alert('Pelanggan berhasil ditambahkan!'); window.location='dashboard.php?page=pelanggan';</script>";
    } else {
        echo "<script>alert('Gagal menambah pelanggan!');</script>";
    }
}
?>


<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pelanggan</title>
    <link href="./output.css" rel="stylesheet">
</head>
<body>
<h2 class="text-2xl font-bold text-center my-4 mt-20">Tambah Pelanggan</h2>

<div class="max-w-md mx-auto bg-white p-6 rounded-lg shadow-lg">
    <form method="POST" class="space-y-4">
        <div>
            <label class="block text-gray-700 font-semibold">Nama:</label>
            <input type="text" name="namaPelanggan" required class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-400 focus:outline-none">
        </div>

        <div>
            <label class="block text-gray-700 font-semibold">Alamat:</label>
            <input type="text" name="alamat" required class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-400 focus:outline-none">
        </div>

        <div>
            <label class="block text-gray-700 font-semibold">No. HP:</label>
            <input type="number" name="no_hp" required class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-400 focus:outline-none">
        </div>

        <button type="submit" name="tambahPelanggan" class="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition">
            Tambah
        </button>
    </form>
</div>
</body>
</html>





