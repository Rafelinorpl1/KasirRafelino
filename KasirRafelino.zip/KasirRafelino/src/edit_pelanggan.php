<?php
session_start();
include "koneksi.php"; 

// Cek apakah ada ID pelanggan yang dikirim
if (!isset($_GET["PelangganID"]) || empty($_GET["PelangganID"]) || !is_numeric($_GET["PelangganID"])) {
    echo "<script>alert('ID Pelanggan tidak ditemukan atau tidak valid!'); window.location='dashboard.php?page=pelanggan';</script>";
    
}

$idPelanggan = intval($_GET["PelangganID"]); // Pastikan ID adalah angka

// Ambil data pelanggan berdasarkan ID
$query = "SELECT * FROM pelanggan WHERE PelangganID = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $idPelanggan);
$stmt->execute();
$result = $stmt->get_result();
$pelanggan = $result->fetch_assoc();

// Jika pelanggan tidak ditemukan, hentikan eksekusi
if (!$pelanggan) {
    echo "<script>alert('Pelanggan tidak ditemukan!'); window.location='dashboard.php?page=pelanggan';</script>";
    
}

// Jika tombol update ditekan
if (isset($_POST["updatePelanggan"])) {
    $namaPelanggan = trim($_POST["namaPelanggan"]);
    $alamat = trim($_POST["alamat"]);
    $no_hp = trim($_POST["no_hp"]);

    // Validasi input (tidak boleh kosong)
    if (!empty($namaPelanggan) && !empty($alamat) && !empty($no_hp)) {
        $query = "UPDATE pelanggan SET NamaPelanggan = ?, Alamat = ?, NomorTelepon = ? WHERE PelangganID = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssi", $namaPelanggan, $alamat, $no_hp, $idPelanggan);

        // Eksekusi update
        if ($stmt->execute()) {
            echo "<script>alert('Pelanggan berhasil diperbarui!'); window.location='dashboard.php?page=pelanggan';</script>";
            exit();
        } else {
            die("Gagal memperbarui pelanggan: " . $stmt->error);
        }
    } else {
        echo "<script>alert('Harap isi semua data dengan benar!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pelanggan</title>
    <link href="./output.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="flex justify-center items-center h-screen">
        <div class="bg-white p-6 rounded-lg shadow-md w-96">
            <h1 class="text-2xl font-bold mb-4 text-center">Edit Pelanggan</h1>
            <form method="POST">
                <label class="block text-sm font-medium">Nama Pelanggan</label>
                <input type="text" name="namaPelanggan" value="<?= htmlspecialchars($pelanggan['NamaPelanggan']) ?>" class="border p-2 w-full mb-2 rounded-lg" required>

                <label class="block text-sm font-medium">Alamat</label>
                <input type="text" name="alamat" value="<?= htmlspecialchars($pelanggan['Alamat']) ?>" class="border p-2 w-full mb-2 rounded-lg" required>

                <label class="block text-sm font-medium">Nomor Telepon</label>
                <input type="text" name="no_hp" value="<?= htmlspecialchars($pelanggan['NomorTelepon']) ?>" class="border p-2 w-full mb-2 rounded-lg" required>

                <button type="submit" name="updatePelanggan" class="bg-blue-500 hover:bg-blue-700 text-white px-4 py-2 rounded w-full mt-2 cursor-pointer">Simpan</button>
            </form>
            <a href="dashboard.php?page=pelanggan" class="block text-center text-gray-600 mt-3">Kembali</a>
        </div>
    </div>
</body>
</html>
