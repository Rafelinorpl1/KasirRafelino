<?php
session_start();
include "koneksi.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $query = "SELECT * FROM user WHERE username = ? AND password = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user) {
        $_SESSION["nama"] = $user["nama"];
        $_SESSION["level"] = $user["level"];
        $_SESSION["show_welcome"] = true; // ✅ Tambahkan ini

        header("Location: dashboard.php");
        exit();
    } else {
        echo "<script>alert('Username atau Password salah!'); window.location='login.php';</script>";
    }
}

?>
