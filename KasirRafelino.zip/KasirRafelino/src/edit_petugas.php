<?php
session_start();
include "koneksi.php";

// Periksa apakah ID dikirim dan valid
if (!isset($_GET["id"]) || empty($_GET["id"]) || !is_numeric($_GET["id"])) {
    echo "<script>alert('ID Petugas tidak valid!'); window.location='dashboard.php?page=petugas';</script>";
    exit();
}

$idPetugas = intval($_GET["id"]);

// Debugging: Pastikan ID diterima dengan benar
// var_dump($idPetugas); exit();

// Ambil data petugas berdasarkan ID
$query = "SELECT * FROM user WHERE id_user = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $idPetugas);
$stmt->execute();
$result = $stmt->get_result();

// Jika petugas tidak ditemukan
// if ($result->num_rows == 0) {
//     echo "<script>alert('Petugas tidak ditemukan di database!'); window.location='dashboard.php?page=petugas';</script>";
//     exit();
// }

$petugas = $result->fetch_assoc(); // Ambil data petugas

// Jika tombol update ditekan
if (isset($_POST["updatePetugas"])) {
    $nama = trim($_POST["nama"]);
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]); // Password baru (jika diisi)

    if (!empty($nama) && !empty($username)) {
        if (!empty($password)) {
            // Enkripsi password sebelum menyimpan
            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
            $query = "UPDATE user SET nama = ?, username = ?, password = ? WHERE id_user = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("sssi", $nama, $username, $hashedPassword, $idPetugas);
        } else {
            // Update tanpa mengubah password
            $query = "UPDATE user SET nama = ?, username = ? WHERE id_user = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ssi", $nama, $username, $idPetugas);
        }

        if ($stmt->execute()) {
            echo "<script>alert('Petugas berhasil diperbarui!'); window.location='manajemen_petugas.php';</script>";
            exit();
        } else {
            echo "<script>alert('Gagal memperbarui petugas!');</script>";
        }
    } else {
        echo "<script>alert('Masukkan data dengan benar!');</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Petugas</title>
    <link href="./output.css" rel="stylesheet">
</head>
<body class="flex justify-center items-center h-screen bg-gray-100">
    <div class="bg-white p-6 rounded-lg shadow-md w-96">
        <h1 class="text-2xl font-bold mb-4 text-center">Edit Petugas</h1>
        <form method="POST">
            <label class="block text-sm font-medium">Nama</label>
            <input type="text" name="nama" value="<?= htmlspecialchars($petugas['nama']) ?>" class="border p-2 w-full mb-2 rounded-lg" required>

            <label class="block text-sm font-medium">Username</label>
            <input type="text" name="username" value="<?= htmlspecialchars($petugas['username']) ?>" class="border p-2 w-full mb-2 rounded-lg" required>

            <label class="block text-sm font-medium">Password (Kosongkan jika tidak ingin diubah)</label>
            <input type="password" name="password" class="border p-2 w-full mb-2 rounded-lg">

            <button type="submit" name="updatePetugas" class="bg-blue-500 hover:bg-blue-700 text-white px-4 py-2 rounded w-full mt-2 cursor-pointer">Simpan</button>
        </form>
        <a href="dashboard.php?page=petugas" class="block text-center text-gray-600 mt-3">Kembali</a>
    </div>
</body>
</html>

