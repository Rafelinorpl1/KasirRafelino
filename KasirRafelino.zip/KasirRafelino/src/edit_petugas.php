<?php
session_start();
include "koneksi.php";



// Pastikan ID petugas dikirimkan
if (!isset($_GET["id_user"]) || empty($_GET["id_user"]) || !is_numeric($_GET["id_user"])) {
    echo "<script>alert('ID Petugas tidak valid!'); window.location='manajemen_petugas.php';</script>";
    exit();
}

$idPetugas = intval($_GET["id_user"]);

// Ambil data petugas berdasarkan ID
$query = "SELECT * FROM user WHERE id_user = ? AND level = 'petugas'";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $idPetugas);
$stmt->execute();
$result = $stmt->get_result();
$petugas = $result->fetch_assoc();

// Jika petugas tidak ditemukan
if (!$petugas) {
    echo "<script>alert('Petugas tidak ditemukan!'); window.location='manajemen_petugas.php';</script>";
    exit();
}

// Jika tombol update ditekan
if (isset($_POST["updatePetugas"])) {
    $nama = trim($_POST["nama"]);
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]); // Password baru (jika diisi)

    if (!empty($nama) && !empty($username)) {
        if (!empty($password)) {
            // Update dengan password baru
            $query = "UPDATE user SET nama = ?, username = ?, password = ? WHERE id_user = ? AND level = 'petugas'";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("sssi", $nama, $username, $password, $idPetugas);
        } else {
            // Update tanpa mengubah password
            $query = "UPDATE user SET nama = ?, username = ? WHERE id_user = ? AND level = 'petugas'";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ssi", $nama, $username, $idPetugas);
        }

        if ($stmt->execute()) {
            echo "<script>alert('Petugas berhasil diperbarui!'); window.location='manajemen_petugas.php';</script>";
            exit();
        } else {
            die("Gagal memperbarui petugas: " . $stmt->error);
        }
    } else {
        echo "<script>alert('Masukkan data dengan benar!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Petugas</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="flex justify-center items-center h-screen bg-gray-100">
    <div class="bg-white p-6 rounded-lg shadow-md w-96">
        <h1 class="text-2xl font-bold mb-4 text-center">Edit Petugas</h1>
        <form method="POST">
            <label class="block text-sm font-medium">Nama</label>
            <input type="text" name="nama" value="<?= htmlspecialchars($petugas['nama']) ?>" class="border p-2 w-full mb-2 rounded-lg" required>

            <label class="block text-sm font-medium">Username</label>
            <input type="text" name="username" value="<?= htmlspecialchars($petugas['username']) ?>" class="border p-2 w-full mb-2 rounded-lg" required>

            <label class="block text-sm font-medium">Password (Kosongkan jika tidak ingin diubah)</label>
            <input type="password" name="password" class="border p-2 w-full mb-2 rounded-lg">

            <button type="submit" name="updatePetugas" class="bg-blue-500 hover:bg-blue-700 text-white px-4 py-2 rounded w-full mt-2 cursor-pointer">Simpan</button>
        </form>
        <a href="manajemen_petugas.php" class="block text-center text-gray-600 mt-3">Kembali</a>
    </div>
</body>
</html>
