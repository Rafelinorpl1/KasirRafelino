

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="./output.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
        </style>
    <title>Dashboard | Kasir Rapel</title>
</head>
<body class="bg-gray-300 font-[Poppins]">
    <div class="sidebar fixed top-0 bottom-0 lg:left-0 p-2 w-[300px] overflow-y-auto text-center bg-gray-900">
        <div class="text-gray-100">
            <div class="p-2.5 mt-1 flex items-center ">
                <h1 class="font-bold text-gray-200 text-2xl ml-3 cursor-pointer">Kasir Rapel</h1>
            </div>
        </div>
        <hr class="my-2 text-gray-600">

        <div class="p-2.5 mt-3 flex items-center rounded-md px-4 duration-300 cursor-pointer hover:bg-blue-600 text-white">
            <a href="?page=dashboard" class="text-[15px] ml-4 text-gray-200">Home</a>
        </div>

        <div class="p-2.5 mt-3 flex items-center rounded-md px-4 duration-300 cursor-pointer hover:bg-blue-600 text-white">
            <a href="?page=produk" class="text-[15px] ml-4 text-gray-200">Manajemen Produk</a>
        </div>

        <div class="p-2.5 mt-3 flex items-center rounded-md px-4 duration-300 cursor-pointer hover:bg-blue-600 text-white">
            <a href="?page=pelanggan" class="text-[15px] ml-4 text-gray-200">Manajemen Pelanggan</a>
        </div>

        <div class="p-2.5 mt-[21rem] flex items-center rounded-md px-4 duration-300 cursor-pointer text-red-500  hover:bg-red-600 hover:text-white">
            <a href="logout.php" class="text-[15px] ml-4 ">Logout</a>
        </div>
    </div> 

     <!-- Konten Dashboard -->
    <div class="ml-[320px]">
        <?php
        if (isset($_GET['page'])) {
            $page = $_GET['page'];

            // Memasukkan file yang sesuai dengan menu yang diklik
            if ($page == "dashboard") {
                include("dashboard_content.php");
            } elseif ($page == "produk") {
                include("manajemen_produk.php");
            } elseif ($page == "pelanggan") {
                include("manajemen_pelanggan.php");
            } else {
                echo "<div class='p-6 text-white'><h1 class='text-3xl font-bold'>404</h1><p>Halaman tidak ditemukan.</p></div>";
            }
        } else {
            include("dashboard_content.php"); // Default tampil dashboard
        }
        ?>
    </div>
</body>
</html>