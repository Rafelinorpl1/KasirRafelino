<?php
include "koneksi.php";
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Laporan</title>
    <link href="./output.css" rel="stylesheet">
<body class="bg-gray-100 p-6">
<h2 class="text-2xl font-bold mb-4 text-center mt-4">Laporan Transaksi</h2>   
        <div class="max-w-4xl mx-auto bg-white p-6 rounded-lg shadow-md">
        
        <table id="print-section" class="w-full border-collapse border border-gray-300">
            <thead class="bg-gray-200">
                <tr>
                    <th class="border p-2">No</th>
                    <th class="border p-2">Tanggal</th>
                    <th class="border p-2">Pelanggan</th>
                    <th class="border p-2">Total</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = "SELECT t.id, t.tanggal, p.NamaPelanggan, t.total_harga FROM transaksi t
                          JOIN pelanggan p ON t.pelanggan_id = p.PelangganID";
                $result = $conn->query($query);
                $no = 1;

                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                        <td class='border p-2 text-center'>{$no}</td>
                        <td class='border p-2'>{$row['tanggal']}</td>
                        <td class='border p-2'>{$row['NamaPelanggan']}</td>
                        <td class='border p-2'>Rp " . number_format($row['total_harga'], 0, ',', '.') . "</td>
                    </tr>";
                    $no++;
                }
                ?>
            </tbody>
        </table>

        <button onclick="printLaporan()" class="mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-700">
            Cetak Laporan
        </button>
        
        <script>
            function printLaporan() {
    window.print();
}
        </script>

    </div>
    
    <style>
        @media print {
    body * {
        visibility: hidden; /* Sembunyikan semua elemen */
    }
    #print-section, #print-section * {
        visibility: visible; /* Tampilkan hanya bagian yang dicetak */
    }
    #print-section {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
    }
}

    </style>
</body>
</html>
