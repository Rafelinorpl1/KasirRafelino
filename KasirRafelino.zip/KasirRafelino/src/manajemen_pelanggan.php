<?php
include "koneksi.php"; // Koneksi ke database
?>

<h2 class="text-3xl font-bold text-center mt-5 mb-5">Manajemen Pelanggan</h2>
<br>

<a href="tambah_pelanggan.php" type="submit" class="text-white bg-blue-500 hover:bg-blue-700 px-4 py-2 mt-0 rounded cursor-pointer">
    <button>Tambah Pelanggan</button>
</a>
<div class="mt-5 bg-white p-5 shadow-md rounded-lg mr-4">
    <h2 class="text-xl font-semibold mb-3">Daftar Pelanggan</h2>
<table class="w-full">
    <thead>
        <tr class="bg-gray-200">
            <th class="border border-gray-300 p-2">Nama Pelanggan</th>
            <th class="border border-gray-300 p-2">Alamat</th>
            <th class="border border-gray-300 p-2">Nomor Telepon</th>
            <th class="border border-gray-300 p-2">Aksi</th>
        </tr>
    </thead>
    <tbody>
    <?php
    require 'koneksi.php';

    $query = "SELECT * FROM pelanggan";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) { 
            echo "<tr class=''>
                <td class='border border-gray-300 p-2 text-center'>" . htmlspecialchars($row['NamaPelanggan']) . "</td>
                <td class='border border-gray-300 p-2 text-center'>" . htmlspecialchars($row['Alamat']) . "</td>
                <td class='border border-gray-300 p-2 text-center'>" . htmlspecialchars($row['NomorTelepon']) . "</td>
                <td class='border border-gray-300 p-2 flex flex-row justify-center'>
                    <a href='edit_pelanggan.php?PelangganID=" . htmlspecialchars($row['PelangganID']) . "' class='text-white bg-blue-500 hover:bg-blue-700 px-5 py-1 rounded-sm'>Edit</a> |
                    <a href='hapus_pelanggan.php?PelangganID=" . htmlspecialchars($row['PelangganID']) . "' onclick='return confirm(\"Yakin ingin menghapus pelanggan ini?\")' class='text-white bg-red-600 hover:bg-red-700 px-2 py-1 rounded-sm'>Hapus</a>
                </td>
            </tr>";
        }
    } else {
        echo "<tr><td colspan='5' class='border p-2 text-center'>Tidak ada data pelanggan.</td></tr>";
    }
    ?>
</tbody>

</table>
</div>