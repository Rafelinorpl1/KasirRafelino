<?php
session_start();
include "koneksi.php"; // Koneksi ke database

// Proses tambah transaksi
if (isset($_POST["tambah_transaksi"])) {
    $pelanggan_id = $_POST["pelanggan_id"];
    $tanggal = date("Y-m-d");
    $produk_ids = $_POST["produk_id"];
    $jumlahs = $_POST["jumlah"];
    $total_harga = 0;

    // Simpan transaksi utama
    $query = "INSERT INTO transaksi (pelanggan_id, tanggal, total_harga) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("isd", $pelanggan_id, $tanggal, $total_harga);
    $stmt->execute();
    $transaksi_id = $stmt->insert_id;

    // Simpan transaksi detail (produk yang dipilih)
    foreach ($produk_ids as $key => $produk_id) {
        $jumlah = intval($jumlahs[$key]);

        // Ambil harga dan stok produk dari database
        $harga_query = "SELECT Harga, Stok FROM produk WHERE ProdukID = ?";
        $stmt_harga = $conn->prepare($harga_query);
        $stmt_harga->bind_param("i", $produk_id);
        $stmt_harga->execute();
        $result_harga = $stmt_harga->get_result();
        $row_harga = $result_harga->fetch_assoc();
        $harga_satuan = $row_harga["Harga"];
        $stok_tersedia = $row_harga["Stok"];

        if ($jumlah > $stok_tersedia) {
            echo "<script>alert('Stok produk tidak mencukupi!'); window.location='dashboard.php?page=transaksi';</script>";
            exit();
        }

        $subtotal = $harga_satuan * $jumlah;
        $total_harga += $subtotal;

        $query = "INSERT INTO transaksi_detail (transaksi_id, produk_id, jumlah, harga) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("iiid", $transaksi_id, $produk_id, $jumlah, $subtotal);
        $stmt->execute();

        // Kurangi stok produk
        $update_stok_query = "UPDATE produk SET Stok = Stok - ? WHERE ProdukID = ?";
        $stmt = $conn->prepare($update_stok_query);
        $stmt->bind_param("ii", $jumlah, $produk_id);
        $stmt->execute();
    }

    // Update total harga transaksi
    $update_query = "UPDATE transaksi SET total_harga = ? WHERE id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("di", $total_harga, $transaksi_id);
    $stmt->execute();

    echo "<script>alert('Transaksi berhasil ditambahkan!'); window.location='admin_dashboard.php?page=transaksi';</script>";
}

// Ambil daftar transaksi
$query = "SELECT transaksi.id, pelanggan.NamaPelanggan, transaksi.tanggal, transaksi.total_harga 
          FROM transaksi 
          JOIN pelanggan ON transaksi.pelanggan_id = pelanggan.PelangganID 
          ORDER BY transaksi.tanggal DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi</title>
    <link href="./output.css" rel="stylesheet">
</head>
<body class="bg-gray-100 p-6">
    <h1 class="text-2xl font-bold mb-4 mt-4">Daftar Transaksi</h1>

    <!-- Form Tambah Transaksi -->
    <div class="bg-white p-4 rounded shadow-md mb-4 ml-0 mr-4">
        <h2 class="text-lg font-semibold mb-2">Tambah Transaksi</h2>
        <form method="POST">
            <label class="block">Pelanggan:</label>
            <select name="pelanggan_id" class="border p-2 w-full mb-2 rounded-lg" required>
                <option value="">Pilih Pelanggan</option>
                <?php
                $pelanggan_query = "SELECT * FROM pelanggan";
                $pelanggan_result = $conn->query($pelanggan_query);
                while ($row = $pelanggan_result->fetch_assoc()) {
                    echo "<option value='".$row['PelangganID']."'>".$row['NamaPelanggan']."</option>";
                }
                ?>
            </select>

            <!-- Produk -->
            <label class="block">Produk:</label>
            <div id="produk-container">
                <div class="produk-item flex space-x-2">
                    <select name="produk_id[]" class="border p-2 w-1/3 rounded-lg" required onchange="updateStok(this)">
                        <option value="">Pilih Produk</option>
                        <?php
                        $produk_query = "SELECT * FROM produk";
                        $produk_result = $conn->query($produk_query);
                        while ($row = $produk_result->fetch_assoc()) {
                            echo "<option value='".$row['ProdukID']."' data-stok='".$row['Stok']."' data-harga='".$row['Harga']."'>".$row['NamaProduk']." - Rp ".number_format($row['Harga'], 2, ',', '.')."</option>";
                        }
                        ?>
                    </select>
                    <input type="number" name="jumlah[]" class="border p-2 w-1/4 rounded-lg" placeholder="Jumlah" required min="1">
                    <input type="text" class="stok-info border p-2 w-1/3 bg-gray-100 rounded-lg text-center" placeholder="Stok" readonly>
                </div>
            </div>

            <button type="button" onclick="tambahProduk()" class="bg-green-500 hover:bg-green-700 text-white px-3 py-1 rounded mt-2">Tambah Produk</button>

            <button type="submit" name="tambah_transaksi" class="bg-blue-500 hover:bg-blue-700 text-white px-4 py-2 rounded w-full mt-2 cursor-pointer">Tambah Transaksi</button>
        </form>
    </div>

    <!-- Tabel Transaksi -->
    <div class="ml-0 mr-4">
        <table class="w-full bg-white shadow-md rounded border-collapse border">
            <thead class="bg-gray-200">
                <tr>
                    <th class="border py-2 px-4">No</th>
                    <th class="border py-2 px-4">Pelanggan</th>
                    <th class="border py-2 px-4">Tanggal</th>
                    <th class="border py-2 px-4">Total Harga</th>
                    <th class="border py-2 px-4">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                while ($row = $result->fetch_assoc()) {
                    echo "<tr class='border-t'>
                            <td class='border py-2 px-4 text-center'>{$no}</td>
                            <td class='border py-2 px-4 text-center'>{$row['NamaPelanggan']}</td>
                            <td class='border py-2 px-4 text-center'>{$row['tanggal']}</td>
                            <td class='border py-2 px-4 text-center'>Rp " . number_format($row['total_harga'], 2, ',', '.') . "</td>
                            <td class='border py-2 px-4 text-center'>
                                <a href='hapus_transaksi.php?id={$row['id']}' class='bg-red-500 text-white px-2 py-1 rounded'>Hapus</a>
                            </td>
                        </tr>";
                    $no++;
                }
                ?>
            </tbody>
        </table>
    </div>
    

    <script>
        function tambahProduk() {
            let container = document.getElementById("produk-container");
            let newProduk = document.querySelector(".produk-item").cloneNode(true);
            container.appendChild(newProduk);
        }

        function updateStok(select) {
            let stokInfo = select.parentElement.querySelector(".stok-info");
            let selectedOption = select.options[select.selectedIndex];
            stokInfo.value = "Stok: " + selectedOption.getAttribute("data-stok");
        }
    </script>
</body>
</html>
