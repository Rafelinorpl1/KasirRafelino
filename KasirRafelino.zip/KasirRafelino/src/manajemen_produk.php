<?php

include "koneksi.php"; // Koneksi ke database

// Handle Tambah Produk
if (isset($_POST["tambah"])) {
    $nama = $_POST["nama"];
    $harga = $_POST["harga"];
    $stok = $_POST["stok"];

    $query = "INSERT INTO produk (NamaProduk, Harga, Stok) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sii", $nama, $harga, $stok);

    if ($stmt->execute()) {
        echo "<script>alert('Produk berhasil ditambahkan!'); window.location='dashboard.php?page=produk';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan produk!');</script>";
    }
}

// Handle Hapus Produk
if (isset($_GET["hapus"])) {
    $id = $_GET["hapus"];
    $query = "DELETE FROM produk WHERE ProdukID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    echo "<script>alert('Produk berhasil dihapus!'); window.location='manajemen_produk.php';</script>";
}

// Ambil data produk
$query = "SELECT * FROM produk";
$result = $conn->query($query);
?>


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Produk</title>
    <link href="./output.css" rel="stylesheet">

<body class="bg-gray-100">
    <div class="container mx-auto p-6 pl-0">
        <h1 class="text-3xl font-bold text-center mb-5">Manajemen Produk</h1>

        <!-- Form Tambah Produk -->
        <div class="bg-white p-5 shadow-md rounded-lg">
            <h2 class="text-xl font-semibold mb-3">Tambah Produk</h2>
            <form method="POST">
                <input type="text" name="nama" placeholder="Nama Produk" required class="border p-2 w-full mb-2">
                <input type="number" name="harga" placeholder="Harga" required class="border p-2 w-full mb-2">
                <input type="number" name="stok" placeholder="Stok" required class="border p-2 w-full mb-2">
                <button type="submit" name="tambah" class="bg-blue-500 hover:bg-blue-700 text-white px-4 py-2 rounded cursor-pointer w-full">Tambah</button>
            </form>
        </div>

        <!-- Tabel Produk -->
        <div class="mt-5 bg-white p-5 shadow-md rounded-lg">
            <h2 class="text-xl font-semibold mb-3">Daftar Produk</h2>
            <table class="w-full border-collapse border">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="border p-2">ID</th>
                        <th class="border p-2">Nama</th>
                        <th class="border p-2">Harga</th>
                        <th class="border p-2">Stok</th>
                        <th class="border p-2" style="width: 20%;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td class="border p-2"><?= $row["ProdukID"] ?></td>
                            <td class="border p-2"><?= $row["NamaProduk"] ?></td>
                            <td class="border p-2"><?= $row["Harga"] ?></td>
                            <td class="border p-2"><?= $row["Stok"] ?></td>
                            <td class="border p-2  ">
                                <a href="edit_produk.php?ProdukID=<?= $row["ProdukID"] ?>" class="text-white bg-blue-500 hover:bg-blue-700 px-5 py-1 rounded-sm">Edit</a> |
                                <a href="hapus_produk.php?ProdukID=<?= $row["ProdukID"] ?>" onclick="return confirm('Hapus produk ini?')" class="text-white bg-red-600 hover:bg-red-700 px-2 py-1 rounded-sm">Hapus</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

    </div>
</body>

