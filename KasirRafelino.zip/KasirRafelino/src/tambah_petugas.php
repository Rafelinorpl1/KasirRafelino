<?php
session_start();
include "koneksi.php";

if (isset($_POST["tambah_petugas"])) {
    $nama = trim($_POST["nama"]);
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);
    $level = "petugas"; // Hanya bisa menambah petugas

    // Cek apakah username sudah ada
    $cekUser = $conn->prepare("SELECT * FROM user WHERE username = ?");
    $cekUser->bind_param("s", $username);
    $cekUser->execute();
    $result = $cekUser->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('Username sudah digunakan!'); window.location='tambah_petugas.php';</script>";
    } else {
        // Tambah petugas ke database
        $query = "INSERT INTO user (nama, username, password, level) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssss", $nama, $username, $password, $level);

        if ($stmt->execute()) {
            echo "<script>alert('Petugas berhasil ditambahkan!'); window.location='manajemen_petugas.php';</script>";
        } else {
            echo "<script>alert('Gagal menambahkan petugas!');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Petugas</title>
    <link href="./output.css" rel="stylesheet">

</head>
<body class="flex justify-center items-center h-screen bg-gray-100">
    <div class="bg-white p-6 rounded-lg shadow-md w-96">
        <h1 class="text-2xl font-bold mb-4 text-center">Tambah Petugas</h1>
        <form method="POST">
            <label class="block text-sm font-medium">Nama</label>
            <input type="text" name="nama" class="border p-2 w-full mb-2 rounded-lg" required>

            <label class="block text-sm font-medium">Username</label>
            <input type="text" name="username" class="border p-2 w-full mb-2 rounded-lg" required>

            <label class="block text-sm font-medium">Password</label>
            <input type="password" name="password" class="border p-2 w-full mb-2 rounded-lg" required>

            <button type="submit" name="tambah_petugas" class="bg-blue-500 hover:bg-blue-700 text-white px-4 py-2 rounded w-full mt-2 cursor-pointer">Tambah</button>
        </form>
        <a href="admin_dashboard.php?page=petugas" class="block text-center text-gray-600 mt-3">Kembali</a>
    </div>
</body>
</html>
