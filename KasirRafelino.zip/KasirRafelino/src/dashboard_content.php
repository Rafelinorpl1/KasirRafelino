<?php
include "koneksi.php"; // Hubungkan ke database

// Hitung Total Transaksi
$query_transaksi = "SELECT COUNT(*) AS total_transaksi FROM transaksi";
$result_transaksi = $conn->query($query_transaksi);
$row_transaksi = $result_transaksi->fetch_assoc();
$total_transaksi = $row_transaksi['total_transaksi'];

// Hitung Total Pendapatan
$query_pendapatan = "SELECT SUM(total_harga) AS total_pendapatan FROM transaksi";
$result_pendapatan = $conn->query($query_pendapatan);
$row_pendapatan = $result_pendapatan->fetch_assoc();
$total_pendapatan = $row_pendapatan['total_pendapatan'];

// Jika tidak ada transaksi, set total pendapatan ke 0
$total_pendapatan = $total_pendapatan ? $total_pendapatan : 0;
?>

<div class="bg-white shadow-md rounded-lg p-6 mt-4 ml-0 mr-4">
    <h1 class="text-3xl font-bold mb-4 text-center">Dashboard Utama</h1>
    <p class="text-gray-700 text-center">
        Ringkasan data transaksi dan keuangan.
    </p>

    <div class="mt-6 grid grid-cols-2 gap-6">
        <!-- Total Transaksi -->
        <div class="p-6 bg-blue-500 text-white rounded-lg text-center">
            <h2 class="text-3xl font-semibold"><?= number_format($total_transaksi) ?></h2>
            <p class="text-lg">Total Transaksi</p>
        </div>

        <!-- Total Pendapatan -->
        <div class="p-6 bg-green-500 text-white rounded-lg text-center">
            <h2 class="text-3xl font-semibold">Rp <?= number_format($total_pendapatan, 0, ',', '.') ?></h2>
            <p class="text-lg">Total Pendapatan</p>
        </div>
    </div>
</div>
