<?php

include "koneksi.php"; 



// Ambil data petugas dari database
$query = "SELECT * FROM user WHERE level = 'petugas'";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Petugas</title>
    
    <link href="./output.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="container mx-auto my-10 p-6 bg-white shadow-lg rounded-lg">
        <h1 class="text-2xl font-bold mb-4 text-center">Manajemen Petugas</h1>

        <a href="tambah_petugas.php" class="bg-green-500 text-white px-4 py-2 rounded mb-4 inline-block">Tambah Petugas</a>

        <table class="w-full border-collapse border border-gray-300 mt-4">
            <thead>
                <tr class="bg-gray-200">
                    <th class="border border-gray-300 px-4 py-2">ID</th>
                    <th class="border border-gray-300 px-4 py-2">Nama</th>
                    <th class="border border-gray-300 px-4 py-2">Username</th>
                    <th class="border border-gray-300 px-4 py-2">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td class="border border-gray-300 px-4 py-2"><?= $row["id_user"] ?></td>
                    <td class="border border-gray-300 px-4 py-2"><?= htmlspecialchars($row["nama"]) ?></td>
                    <td class="border border-gray-300 px-4 py-2"><?= htmlspecialchars($row["username"]) ?></td>
                    <td class="border border-gray-300 px-4 py-2">
                        <a href="edit_petugas.php?id=<?= $row["id_user"] ?>" class="bg-blue-500 text-white px-2 py-1 rounded">Edit</a>
                        <a href="hapus_petugas.php?id=<?= $row["id_user"] ?>" class="bg-red-500 text-white px-2 py-1 rounded" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
