<?php
session_start();
include "koneksi.php";

// Cek apakah ID ada di URL
if (!isset($_GET['PelangganID']) || empty($_GET['PelangganID'])) {
    die("Error: ID pelanggan tidak ditemukan.");
}

$idPelanggan = intval($_GET['PelangganID']); // Pastikan ID adalah angka

// Hapus produk dari database
$query = "DELETE FROM pelanggan WHERE PelangganID = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $idPelanggan);

if ($stmt->execute()) {
    echo "<script>alert('Produk berhasil dihapus!'); window.location='admin_dashboard.php?page=pelanggan';</script>";
} else {
    echo "<script>alert('Gagal menghapus produk: " . $stmt->error . "');</script>";
}
?>