<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://unpkg.com/@tailwindcss/browser@4"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
        </style>
    <title>Kasir Rapel</title>
</head>
<body class="bg-white w-[95%]">
    
    <section class=>
        <div class="flex justify-center items-center w-full py-16 absolute top-0">
            <h1 class="text-4xl text-slate-600 font-[Poppins] font-semibold">SELAMAT DATANG DI KASIR RAPEL</h1>
        </div>

        <div class="flex items-center justify-center w-full h-screen mt-0">
            <!-- Bagian Kiri (Logo) -->
            <div class="w-1/2 flex justify-center">
                <img src="./Images/logokasir.png" alt="Logo Kasir" class="size-[40%]">
            </div>
        
            <!-- Bagian Kanan (Form Login) -->
            <div class="w-1/2 flex justify-center">
                <div class="bg-white p-8 rounded-lg shadow-lg w-[75%]">
                    <button class="text-2xl font-semibold text-center mb-4">Login</button>
                    <form action="login_process.php" method="POST">
                        <div class="mb-4">
                            <label class="block text-gray-700">Username</label>
                            <input type="text" name="username" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Masukkan Username" required>
                        </div>
                        <div class="mb-4">
                            <label class="block text-gray-700">Password</label>
                            <input type="password" name="password" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Masukkan Password" required>
                        </div>
                        <button type="submit" class="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 transition">Login</button>
                    </form>
                </div>
            </div>
        </div>    
    </section>    
</body>



</html>