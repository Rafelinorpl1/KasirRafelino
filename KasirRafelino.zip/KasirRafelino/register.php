<?php
session_start();
include "koneksi.php"; // Koneksi ke database

if (isset($_POST["register"])) {
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);
    $role = trim($_POST["level"]); // Bisa "admin" atau "petugas"

    // Cek apakah username sudah ada
    $cek_user = $conn->prepare("SELECT username FROM user WHERE username = ?");
    $cek_user->bind_param("s", $username);
    $cek_user->execute();
    $result = $cek_user->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('Username sudah digunakan!'); window.location='register.php';</script>";
        exit();
    }

    // Simpan user ke database
    $query = "INSERT INTO user (username, password, level) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sss", $username, $password, $role);

    if ($stmt->execute()) {
        echo "<script>alert('Pendaftaran berhasil! Silakan login.'); window.location='login.php';</script>";
    } else {
        echo "<script>alert('Gagal mendaftar!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">
    <div class="bg-white p-6 rounded-lg shadow-md w-96">
        <h1 class="text-2xl font-bold mb-4 text-center">Register</h1>
        <form method="POST">
            <label class="block text-sm font-medium">Username</label>
            <input type="text" name="username" class="border p-2 w-full mb-2 rounded-lg" required>

            <label class="block text-sm font-medium">Password</label>
            <input type="password" name="password" class="border p-2 w-full mb-2 rounded-lg" required>

            <label class="block text-sm font-medium">Role</label>
            <select name="role" class="border p-2 w-full mb-2 rounded-lg" required>
                <option value="admin">Admin</option>
                <option value="petugas">Petugas</option>
            </select>

            <button type="submit" name="register" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded w-full mt-2 cursor-pointer">Register</button>
        </form>
        <p class="text-center text-gray-600 mt-3">Sudah punya akun? <a href="login.php" class="text-blue-500">Login</a></p>
    </div>
</body>
</html>
