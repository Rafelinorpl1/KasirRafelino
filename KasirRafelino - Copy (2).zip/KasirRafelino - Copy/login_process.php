<?php
session_start();
include "koneksi.php"; // Hubungkan ke database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Debug: Cek apakah input diterima
    echo "Input Username: " . $username . "<br>";
    echo "Input Password: " . $password . "<br>";

    // Query untuk mencari user berdasarkan username
    $query = "SELECT * FROM user WHERE username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    // Debug: Cek apakah query menemukan user
    if ($result->num_rows == 0) {
        echo "❌ Username tidak ditemukan di database!";
        exit();
    } else {
        $user = $result->fetch_assoc();
        echo "✅ User ditemukan! Role: " . $user["role"] . "<br>";
        

        // Debug: Tampilkan password dari database
        echo "Password dari database: " . $user["password"] . "<br>";

        // Cek password
        if ($password == $user["password"]) { 
            $_SESSION["user"] = $user["username"];
            $_SESSION["role"] = $user["role"];

            echo "✅ Login berhasil! Mengarahkan ke halaman...";
            if ($user["role"] == "admin") {
                header("Location: admin_dashboard.php");
            } else {
                header("Location: petugas_dashboard.php");
            }
            exit();
        } else {
            echo "❌ Password salah!";
            exit();
        }
    }
}
?>
