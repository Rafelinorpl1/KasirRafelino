<?php
$total_transaksi = 120;
$total_pendapatan = 7500000;
$produk_terlaris = "Kopi Susu";
$stok_habis = 5;
?>

<div class="p-6">
    <h1 class="text-3xl font-bold text-gray-900 mb-6">Dashboard Kasir</h1>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="bg-white p-6 rounded-lg shadow-md">
            <h2 class="text-xl font-semibold">Total Transaksi</h2>
            <p class="text-3xl font-bold mt-2"><?= $total_transaksi; ?></p>
        </div>
        <div class="bg-white p-6 rounded-lg shadow-md">
            <h2 class="text-xl font-semibold">Total Pendapatan</h2>
            <p class="text-3xl font-bold mt-2">Rp <?= number_format($total_pendapatan, 0, ',', '.'); ?></p>
        </div>
        <div class="bg-white p-6 rounded-lg shadow-md">
            <h2 class="text-xl font-semibold">Produk Terlaris</h2>
            <p class="text-2xl font-bold mt-2"><?= $produk_terlaris; ?></p>
        </div>
    </div>

    <div class="mt-6">
        <div class="bg-red-500 text-white p-4 rounded-lg shadow-md">
            <p>⚠ Ada <strong><?= $stok_habis; ?></strong> produk yang hampir habis. Segera restock!</p>
        </div>
    </div>
</div>