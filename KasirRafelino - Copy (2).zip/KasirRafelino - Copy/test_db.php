<?php
include "koneksi.php";

$query = "SELECT * FROM user";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "Username: " . $row["username"] . " - Password: " . $row["password"] . " - Role: " . $row["role"] . "<br>";
    }
} else {
    echo "Database kosong atau tidak terhubung!";
}
?>
